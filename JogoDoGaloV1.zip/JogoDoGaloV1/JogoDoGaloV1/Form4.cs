﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JogoDoGaloV1
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 f =(Form3) this.Owner;
             string fileLoc = @"c:\Hiscore\Hiscore.txt";

             FileStream fs = null;
             if (!File.Exists(fileLoc))
             {
                 using (fs = File.Create(fileLoc))
                 {
                     using (StreamWriter sw = new StreamWriter(fileLoc))
                     {
                        
                        sw.Write(f.textBox1.Text);
                         
                     }
                 }
             }
             else if (File.Exists(fileLoc))
             {
                 using (StreamWriter sw = new StreamWriter(fileLoc))
                 {
                    
                    sw.Write(f.textBox1.Text);
                     this.Close();
                 }
             }
            

        }
    }
}
