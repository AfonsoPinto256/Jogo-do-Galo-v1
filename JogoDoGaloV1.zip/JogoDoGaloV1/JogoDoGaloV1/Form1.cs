﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JogoDoGaloV1
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();          
        }
        
        
        
        private void novoJogoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 child = new Form5();
            child.MdiParent = this;
            child.Show();       
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void terminarToolStripMenuItem_Click(object sender, EventArgs e)
        {                  
            this.Close();
        }

        private void scoreboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileLoc = @"c:\Hiscore\Hiscore.txt";
            if (File.Exists(fileLoc))
            {
                using (TextReader tr = new StreamReader(fileLoc))
                {
                    MessageBox.Show(tr.ReadLine());
                }
            }

        }
      
        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
          
        }

        private void ficheiroToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
