﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JogoDoGaloV1
{
    
    public partial class Form5 : Form
    {
        private JogoDePollo jogo = new JogoDePollo();
        public Form5()
        {
            InitializeComponent();
            Startup();
        }
        private void Startup()
        {
            jogo.IniciarJogo();

            foreach (Control item in this.Controls)
            {
                if ((item.Tag != null) && (item.Tag.ToString() != ""))
                {
                    item.Text = "";
                }
            }
        }

        private void novoJogoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form5 novo = new Form5();
            novo.ShowDialog();
        }

        private void terminarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void btnJogar_Click(object sender, EventArgs e)
        {
            if (jogo.EndGame)
            {
                MessageBox.Show("Jogo já terminado!");
                return;
            }

            string strPosicao = (sender as Button).Tag.ToString();
            int posicao = Convert.ToInt32(strPosicao);

            EstadoJogo estadoJogada = jogo.Jogar(posicao);

            if (jogo.EndGame)
            {
                (sender as Button).Text = jogo.Peca;
                Form3 f = new Form3();

                switch (estadoJogada)
                {
                    case EstadoJogo.Vitoria1:
                        f.label1.Text = "Venceu o Jogador 1";
                        f.ShowDialog(this);
                        break;
                    case EstadoJogo.Vitoria2:
                        f.label1.Text = "Venceu o Jogador 2";
                        f.ShowDialog(this);
                        break;
                    case EstadoJogo.Empate:
                        MessageBox.Show($"Empate");
                        break;
                }
            }
            else
            {
                if (!((estadoJogada == EstadoJogo.Invalido) ||
                 (estadoJogada == EstadoJogo.Ocupado)))
                {
                    if (jogo.Jogador == 1)
                    {
                        (sender as Button).Text = "O";

                    }
                    else
                    {
                        (sender as Button).Text = "X";
                    }

                }
                else
                {
                    MessageBox.Show($"Posição ocupada!");
                }
            }
        }

        private void scoreboardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string fileLoc = @"c:\Hiscore\Hiscore.txt";
            if (File.Exists(fileLoc))
            {
                using (TextReader tr = new StreamReader(fileLoc))
                {
                    MessageBox.Show(tr.ReadLine());
                }
            }
        }
    }
}
